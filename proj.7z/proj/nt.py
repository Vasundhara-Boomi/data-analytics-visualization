import nltk
nltk.download('stopwords')