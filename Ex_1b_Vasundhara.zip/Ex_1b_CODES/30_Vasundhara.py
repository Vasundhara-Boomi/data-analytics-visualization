import numpy as np
# create a 5x5 array with random values
nums = np.random.rand(5, 5)
print("Original array elements:")
print(nums)
# find the second-largest value in each row
second_largest = np.partition(nums, -2, axis=1)[:, -2]
print("\nSecond-largest value in each row:")
print(second_largest)
