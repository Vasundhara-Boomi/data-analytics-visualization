import numpy as np
x = np.array([8, 3])
y = np.array([6, 12])
print("Original vectors:")
print(x)
print(y)
print("Inner product of said vectors:")
print(np.dot(x, y))