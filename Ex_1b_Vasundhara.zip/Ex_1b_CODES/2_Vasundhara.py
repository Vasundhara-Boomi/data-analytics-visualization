import numpy as np

matrix = np.identity(3)
print("3x3 identity matrix:")
print(matrix)

# stacking the matrix vertically
vert_stack = np.vstack((matrix, matrix, matrix))

# stacking the matrix horizontally
horz_stack = np.hstack((matrix, matrix, matrix))
print("Vertical Stack:\n", vert_stack)
print("Horizontal Stack:\n", horz_stack)