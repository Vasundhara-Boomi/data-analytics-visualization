import numpy as np
m = np.mat("3 -2;1 0")
print("Original matrix:")
print(m)
w, v = np.linalg.eig(m) 
print( "Eigenvalues of the said matrix",w)
print( "Eigenvectors of the said matrix",v)