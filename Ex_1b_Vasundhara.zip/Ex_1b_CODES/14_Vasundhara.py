import numpy as np
np.set_printoptions(linewidth=100)
student =  np.array([['01', 'V', 'Vasundhara', 30.21],
 ['02', 'V', 'Ram', 29.32],
 ['03', 'V', 'Pooja', 31.00],
 ['04', 'V', 'Dhanu', 30.22],
 ['05', 'V', 'Sanjeev', 30.21],
 ['06', 'V', 'Anjana', 31.00],
 ['07', 'V', 'Simran', 32.00],
 ['08', 'V', 'Rithik', 29.21],
 ['09', 'V', 'Kara', 30.00],
 ['10', 'V', 'Dharshini', 32.00]])
print("Original array:")
print(student)
char='S'
result = student[np.char.startswith(student[:,2], char)]
print("\nTotal weight, where student name starting with",char)
print(np.round(result[:, 3].astype(float).sum(), 2))
char='D'
result = student[np.char.startswith(student[:,2], char)]
print("\nTotal weight, where student name starting with",char)
print(np.round(result[:, 3].astype(float).sum(), 2))
