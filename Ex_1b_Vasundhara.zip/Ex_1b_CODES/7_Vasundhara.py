import numpy as np
a = np.array([[-1,-2],[6,3]])
print("Original array:")
print(a)
result =  np.linalg.det(a)
print("Determinant of the said array:")
print(result)