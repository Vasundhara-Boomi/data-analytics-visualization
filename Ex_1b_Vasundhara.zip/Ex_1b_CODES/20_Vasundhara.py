import numpy as np
x = np.array([1, np.e, np.e**2])
print("Original array: ")
print(x)
print("\nNatural log =", np.log(x))
print("Common log =", np.log10(x))
print("Base 2 log =", np.log2(x))
