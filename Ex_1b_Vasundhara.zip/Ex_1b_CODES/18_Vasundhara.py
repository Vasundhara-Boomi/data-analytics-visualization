import numpy as np
print("Roots of the first polynomial:")
print(np.roots([1, -4, 7]))
print("Roots of the second polynomial:")
print(np.roots([1, -11, 9, 11, -10]))